/**
    KELAS     : IF 39-06
    KELOMPOK  : 5
    NAMA(NIM) : [KM Alfarabi][1301150076] , [Fiqhi Agung][1301154132] , [AA Gde Ratu Pemayun][1301154412] , [Gisela Anggita Ashianti][1301154468]
**/

#include <string>
#include "tanggal.h"

tanggal create_tanggal(int dd,int mm,int yy) {
    /**
    * fungsi mengeset tanggal tgl dengan hari, bulan, dan tahun dan mengembalikan hasilnya
    **/

    tanggal tgl;
    //=================================================
    // YOUR CODE STARTS HERE
    tgl.tgl = dd;
    tgl.bln = mm;
    tgl.thn = yy;
    // YOUR CODE ENDS HERE
    //=================================================
    return tgl;
}

bool cek_tanggal(tanggal tgl) {
    /**
    * fungsi mengecek tanggal
    * fungsi mengembalikan nilai true jika isi tanggal sesuai dengan bulannya
    * fungsi mengembalikan nilai false jika isi tanggal atau bulan atau tahun salah
    **/
    bool ok = true;

    //=================================================
    // YOUR CODE STARTS HERE
        if ((tgl.bln == 1) or (tgl.bln == 3)or(tgl.bln==5)or(tgl.bln==7)or(tgl.bln==9)or(tgl.bln==12)) {
            if ((tgl.tgl >= 1) && (tgl.tgl >32)){
                ok = true;
            }
        }
        else if((tgl.bln==2)or (tgl.bln==4)or(tgl.bln==6) or(tgl.bln==8)or(tgl.bln==10)or(tgl.bln==11)){
            if ((tgl.tgl>=1) && (tgl.tgl >31)) {
                ok = true;
            }
        }
        else{
            ok=false;
        }

    // YOUR CODE ENDS HERE
    //=================================================
    return ok;
}

void show_tanggal(tanggal tgl) {
    string bulan;

    /**
    * fungsi menampilkan tanggal bulan tahun dengan format menampilkan nama bulan
    * contoh : 1 Januari 1980
    **/
    //=================================================
    // YOUR CODE STARTS HERE

    if (tgl.bln==1){
        bulan="januari";
    }
    else if (tgl.bln==2){
        bulan="februari";
    }
    else if (tgl.bln==3){
        bulan="maret";
    }
    else if (tgl.bln==4){
        bulan="april";
    }
    else if (tgl.bln==5){
        bulan="mei";
    }
    else if (tgl.bln==6){
        bulan="juni";
    }
    else if (tgl.bln==7){
        bulan="juli";
    }
    else if(tgl.bln==8){
        bulan="agustus";
    }
    else if(tgl.bln==9){
        bulan="september";
    }
    else if(tgl.bln==10){
        bulan="oktober";
    }
    else if(tgl.bln==11){
        bulan="november";
    }
    else if(tgl.bln==12){
        bulan="desember";
    }
    else {
        bulan="bulan tidak terdaftar";
    }
    cout<<tgl.tgl<<" "<<bulan<<" "<<tgl.thn<<endl;

    // YOUR CODE ENDS HERE
    //=================================================
}

void edit_tanggal(tanggal &tgl, int dd, int mm, int yy) {
    /**
    * fungsi mengubah isi tanggal dari variabel tgl
    **/
    //=================================================
    // YOUR CODE STARTS HERE
    tgl.tgl = dd;
    tgl.bln = mm;
    tgl.thn =yy;

    // YOUR CODE ENDS HERE
    //=================================================
}

int selisih_hari(tanggal tgl1, tanggal tgl2) {
    /**
    * fungsi menghitung selisih hari dari variable tgl1 dan tgl2
    * fungsi selalu mengembalikan selisih dalam nilai positif
    * syarat tahun tgl1 dan tgl2 harus sama
    * jika tahun pada tgl1 berbeda dengan tgl2, maka fungsi mengembalikan nilai -1
    **/
    int selisih = -1;
    int tab;
    //=================================================
    // YOUR CODE STARTS HERE
        if (tgl1.thn == tgl2.thn){
            if (tgl1.bln < tgl2.bln){
                 if ((tgl1.bln == 1) or (tgl1.bln == 3)or(tgl1.bln==5)or(tgl1.bln==7)or(tgl1.bln==9)or(tgl1.bln==12)){
                    tab= 31 - tgl1.tgl;
                 }
                 else if((tgl1.bln==2)or (tgl1.bln==4)or(tgl1.bln==6) or(tgl1.bln==8)or(tgl1.bln==10)or(tgl1.bln==11)){
                    tab = 30 - tgl1.tgl;
                 }
                 selisih=tab+tgl2.tgl;
            }
            else if (tgl1.bln == tgl2.bln){
                    if (tgl1.tgl > tgl2.tgl){
                            selisih = tgl1.tgl - tgl2.tgl;

                    }
                    else if ((tgl1.tgl) == (tgl2.tgl)){
                        selisih = 0;

                    }
                    else if (tgl1.tgl < tgl2.tgl){
                        selisih = tgl2.tgl- tgl1.tgl;

                    }

            }
            else{
                 if ((tgl2.bln == 1) or (tgl2.bln == 3)or(tgl2.bln==5)or(tgl2.bln==7)or(tgl2.bln==9)or(tgl2.bln==12)){
                    tab= 31 - tgl2.tgl;
                 }
                 else if((tgl2.bln==2)or (tgl2.bln==4)or(tgl2.bln==6) or(tgl2.bln==8)or(tgl2.bln==10)or(tgl2.bln==11)){
                    tab = 30 - tgl2.tgl;
                 }
                 selisih=tab+tgl1.tgl;
            }

            }



    // YOUR CODE ENDS HERE
    //=================================================
    return selisih;
}

